# Team Consistency Tasks

- [ ]  Build git-hub repo
- [ ]  get schedules ready
- [ ]  find a room to start
- [ ]  find a bug bounty room to start